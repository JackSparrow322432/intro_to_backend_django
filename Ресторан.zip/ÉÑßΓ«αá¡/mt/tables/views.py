from django.shortcuts import render, redirect
from django.views import View
from .models import Table

class TableListView(View):
    def get(self, request):
        tables = Table.objects.all()
        return render(request, 'table_list.html', {'tables': tables})

class TableCreateView(View):
    def get(self, request):
        return render(request, 'table_list.html')

    def post(self, request):
        number = request.POST.get('number')
        seats = request.POST.get('seats')
        table = Table.objects.create(number=number, seats=seats)
        return redirect('table_list')

class AvailableTablesView(View):
    def get(self, request):
        date = request.GET.get('date')
        available_tables = Table.objects.filter(is_available=True)
        return render(request, 'table_list.html', {'tables': available_tables, 'date': date})
