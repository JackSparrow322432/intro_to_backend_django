from django.urls import path
from . import views

urlpatterns = [
    path('', views.TableListView.as_view(), name='table_list'),
    path('add/', views.TableCreateView.as_view(), name='table_add'),
    path('available/', views.AvailableTablesView.as_view(), name='available_tables'),
]
