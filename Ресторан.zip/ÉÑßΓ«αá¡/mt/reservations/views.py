# reservations/views.py
from django.shortcuts import render, redirect
from django.views import View
from .models import Reservation
from customers.models import Customer
from tables.models import Table

class ReservationCreateView(View):
    def get(self, request):
        customers = Customer.objects.all()
        tables = Table.objects.filter(is_available=True)
        return render(request, 'reservation_form.html', {'customers': customers, 'tables': tables})

    def post(self, request):
        customer_id = request.POST.get('customer')
        table_id = request.POST.get('table')
        date = request.POST.get('date')

        customer = Customer.objects.get(id=customer_id)
        table = Table.objects.get(id=table_id)

        if Reservation.objects.filter(customer=customer, date=date).exists():
            return render(request, 'error.html', {'message': 'User already has a reservation on this date'})

        if Reservation.objects.filter(table=table, date=date).exists():
            return render(request, 'error.html', {'message': 'Table is already reserved for this date'})

        reservation = Reservation.objects.create(customer=customer, table=table, date=date)
        return redirect('reservation_detail', id=reservation.id)


class ReservationDetailView(View):
    def get(self, request):
        return render(request, "reservations/reservation_detail.html")


class ReservationUpdateView(View):
    def get(self, request):
        return render(request, "reservations/reservation_detail.html")


class ReservationDeleteView(View):
    def get(self, request):
        return render(request, "reservations/reservation_detail.html")