# reservations/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.ReservationCreateView.as_view(), name='reservation_add'),
    path('<int:id>/', views.ReservationDetailView.as_view(), name='reservation_detail'),
    path('<int:id>/update/', views.ReservationUpdateView.as_view(), name='reservation_update'),
    path('<int:id>/delete/', views.ReservationDeleteView.as_view(), name='reservation_delete'),
]

