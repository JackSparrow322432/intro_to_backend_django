# customers/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from .models import Customer
from django.http import HttpResponse

# Список всех клиентов
class CustomerListView(View):
    def get(self, request):
        customers = Customer.objects.all()  # Получаем всех клиентов из базы данных
        return render(request, 'customer_list.html', {'customers': customers})

# Создание нового клиента
class CustomerCreateView(View):
    def get(self, request):
        return render(request, 'customer_form.html')  # Форма для создания нового клиента

    def post(self, request):
        name = request.POST.get('name')
        phone = request.POST.get('phone')

        # Создаем нового клиента
        customer = Customer.objects.create(name=name, phone=phone)
        return redirect('customer_list')  # После создания клиента редиректим на список клиентов

# Детали клиента
class CustomerDetailView(View):
    def get(self, request, id):
        customer = get_object_or_404(Customer, id=id)  # Получаем клиента по id или 404, если не найден
        return render(request, 'customer_list.html', {'customer': customer})
