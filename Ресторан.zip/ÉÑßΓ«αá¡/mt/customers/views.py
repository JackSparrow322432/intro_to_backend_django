# customers/views.py
from django.shortcuts import render, redirect
from django.views import View
from django.views.generic import CreateView
from .models import Customer


class CustomerListView(View):
    def get(self, request):
        customers = Customer.objects.all()
        data = [{"id": customer.id, "name": customer.name, "phone": customer.phone} for customer in customers]
        return render(request, 'customer_list.html', {'customers': data})

    def post(self, request):
        name = request.POST.get("name")
        phone = request.POST.get("phone")
        customer = Customer.objects.create(name=name, phone=phone)
        return redirect('customer_list')


class CustomerDetailView(View):
    def get(self, request, id):
        customer = Customer.objects.get(id=id)  # Получаем клиента по ID
        data = {"id": customer.id, "name": customer.name, "phone": customer.phone}
        return render(request, 'customer_detail.html', {'customer': data})


class CustomerCreateView(CreateView):
    model = Customer
    fields = ['name', 'phone']
